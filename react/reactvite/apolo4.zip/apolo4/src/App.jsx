import './App.css'
import Home from './pages/Home'
import Axios from './pages/Axios'
import Page from './pages/Page'
import Blog from './pages/Blog'
import Contact from './pages/Contact'
import { BrowserRouter, Routes, Route } from 'react-router-dom'


function App() {


  return (
    <>
      <div className=''>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />}></Route>
            <Route path="/Shop" element={<Axios />}></Route>
            <Route path="/Page" element={<Page />}></Route>
            <Route path="/Blog" element={<Blog />}></Route>
            <Route path="/Contact" element={<Contact />}></Route>
          </Routes>
        </BrowserRouter>
      </div>




    </>
  )
}

export default App